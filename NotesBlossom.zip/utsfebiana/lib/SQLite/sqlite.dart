import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:utsfebiana/JsonModels/users.dart';
import '../JsonModels/note_model.dart';

class DatabaseHelper {
  final databaseName = "note.db";
  String noteTable =
      "CREATE TABLE notes (noteId INTEGER PRIMARY KEY AUTOINCREMENT, noteTitle TEXT NOT NULL, noteContent TEXT NOT NULL, createdAt TEXT DEFAULT CURRENT_TIMESTAMP)";

  //login method
  Future<bool> login(Users user) async {
    final Database db = await initDB();

    var result = await db.rawQuery(
        "select * from users where usrName = '${user.usrName}' AND usrPassword = '${user.usrPassword}'");
    if (result.isNotEmpty) {
      return true;
    } else {
      return false;
    }
  }

  //signup method
  Future<int> signup(Users user) async {
    final Database db = await initDB();

    return db.insert('users', user.toMap());
  }

  // Search method to find notes by keyword
  Future<List<NoteModel>> searchNotes(String? keyword) async {
    try {
      final Database db = await initDB();
      List<Map<String, Object?>> searchResult = await db.rawQuery(
          "SELECT * FROM notes WHERE noteTitle LIKE '%${keyword ?? ''}%'");
      return searchResult.map((e) => NoteModel.fromMap(e)).toList();
    } catch (e) {
      print("Error searching notes: $e");
      return [];
    }
  }

  // Create Notes
  Future<int> createNote(NoteModel note) async {
    final Database db = await initDB();
    return db.insert('notes', note.toMap());
  }

  // Get Notes
  Future<List<NoteModel>> getNotes() async {
    final Database db = await initDB();
    List<Map<String, Object?>> result = await db.query('notes');
    return result.map((e) => NoteModel.fromMap(e)).toList();
  }

  // Delete Notes
  Future<int> deleteNote(int id) async {
    final Database db = await initDB();
    return db.delete('notes', where: 'noteId = ?', whereArgs: [id]);
  }

  // Update Notes
  Future<int> updateNote(String title, String context, int noteId) async {
    final Database db = await initDB();
    return db.rawUpdate(
        'UPDATE notes SET noteTitle = ?, noteContent = ? WHERE noteId = ?',
        [title, context, noteId]);
  }

  String users =
      "create table users (usrId INTEGER PRIMARY KEY AUTOINCREMENT, usrName TEXT UNIQUE, usrPassword TEXT)";
  Future<Database> initDB() async {
    final databasePath = await getDatabasesPath();
    final path = join(databasePath, databaseName);

    return openDatabase(path, version: 1, onCreate: (db, version) async {
      await db.execute(users);
      await db.execute(noteTable);
    });
  }
}
