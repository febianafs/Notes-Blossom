package com.example.utsfebiana

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
